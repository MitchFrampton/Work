﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Lab5_NETD_3202.Data.Migrations
{
    public partial class ThirdCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_Coachs",
                table: "Coachs");

            migrationBuilder.RenameTable(
                name: "Coachs",
                newName: "Coaches");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Coaches",
                table: "Coaches",
                column: "Name");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_Coaches",
                table: "Coaches");

            migrationBuilder.RenameTable(
                name: "Coaches",
                newName: "Coachs");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Coachs",
                table: "Coachs",
                column: "Name");
        }
    }
}
