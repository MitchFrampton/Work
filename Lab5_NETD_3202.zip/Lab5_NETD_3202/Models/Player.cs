﻿using System.ComponentModel.DataAnnotations;

namespace Lab5_NETD_3202.Models
{
    public class Player
    {
        [Key]
        public string Name { get; set; }
        public int Age { get; set; }
        public string Position { get; set; }
        public int Salary { get; set; } 
    }
}
