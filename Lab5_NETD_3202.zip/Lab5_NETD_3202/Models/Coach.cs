﻿using System.ComponentModel.DataAnnotations;

namespace Lab5_NETD_3202.Models
{
    public class Coach
    {
        
        [Key]
        public string Name { get; set; }
        public int Age { get; set; }
        public int Salary { get; set; }
        
    }
}
